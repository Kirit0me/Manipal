gcd.o: gcd.asm
