	AREA RESET,DATA,READONLY
	EXPORT __Vectors
__Vectors
	DCD 0x10001000
	DCD Reset_Handler
	ALIGN
	AREA mycode,CODE,READONLY
	ENTRY
	EXPORT Reset_Handler
Reset_Handler
	LDR R0, =N1
	LDR R1, [R0]
	MOV R2, #1
	
FA	MUL R2, R2, R1
	SUBS R1, #1
	CMP R1, #1
	BGT FA
	LDR R9, =DST
	STR R2, [R9]
STOP 
	B STOP
	
N1 DCD 0x05
	AREA mydata, DATA, READWRITE
DST DCD 0