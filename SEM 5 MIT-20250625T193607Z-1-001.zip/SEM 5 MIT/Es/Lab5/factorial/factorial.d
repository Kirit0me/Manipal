factorial.o: factorial.asm
