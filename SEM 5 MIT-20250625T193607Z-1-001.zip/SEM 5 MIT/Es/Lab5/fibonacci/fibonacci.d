fibonacci.o: fibonacci.asm
