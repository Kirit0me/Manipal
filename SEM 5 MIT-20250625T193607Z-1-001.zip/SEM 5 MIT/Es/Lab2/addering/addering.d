addering.o: addering.asm
